#!/usr/bin/env bash
set -e  # 중간에 에러 나면 즉시 종료

# 이 스크립트가 있는 디렉토리(= sort.h, libsort.a가 있는 곳)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[*] Installing presidium sort library..."

# 1) 헤더를 /usr/local/include 로 복사
sudo cp "$SCRIPT_DIR/sort.h" /usr/local/include/

# 2) 정적 라이브러리를 /usr/local/lib 로 복사
sudo cp "$SCRIPT_DIR/libsort.a" /usr/local/lib/

# 3) 라이브러리 캐시 갱신
sudo ldconfig

echo "[*] Done."
echo "Now you can use:  #include <sort.h>  and link with -lsort"
