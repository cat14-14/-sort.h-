#include <stdio.h>
#include <sort.h>

int main() {
    int arr[5] = {5, 3, 1, 4, 2};
    sort(arr, 5, SORT_QUICK);

    for (int i = 0; i < 5; i++)
        printf("%d ", arr[i]);

    return 0;
}
